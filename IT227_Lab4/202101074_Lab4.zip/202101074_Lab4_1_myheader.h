double mypow (double a, int b);
long myfact (int n);