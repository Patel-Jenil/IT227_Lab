#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <libgen.h>
#include <math.h>

int factorial(int n) {

    if(n<=1) {
        return 1;
    }

    else {
        return n * factorial(n-1);
    }
}

int main(int argc, char const *argv[]) {

    if (argc!=3) {
        printf("Enter valid argument!\n");
        exit(-1);
    }

    char *ptr;
    double ans=0;
    double x=strtod(argv[1],&ptr);

    for (int i=0; i<=atoi(argv[2]); i++) {
        ans+=(pow(x,i)/factorial(i));
    }

    printf("Child (PID = %d): For x = %lf the first %d terms yield %lf.\n",getpid(),x,atoi(argv[2]),ans);
    exit(ans);

    return 0;
}
