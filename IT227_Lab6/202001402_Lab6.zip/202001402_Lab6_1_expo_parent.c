#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <libgen.h>

int main(int argc, char const *argv[]) {

    if(argc!=3) {
        printf("Please enter valid arguments.\n");
        exit(1);
    }

    pid_t pid, childpid, status;
    pid=fork();
    if (pid!=0) {

        childpid = wait(&status);

        if (WIFEXITED(status)) {
            printf("Child process terminated normally with PID %d & exit code %d\n", childpid, WEXITSTATUS(status));
        }

        else {
            printf("Child process terminated abnormally.\n");
        }

        if (WIFSIGNALED(status)) {
            printf("Child process terminated by signal.\n");
        }

        else {
            printf("Child process not terminated by signal.\n");
        }

        printf("Parent (PID: %d): done\n",getpid());

    }

    else {

        printf("New child process created.\n");

        int return_val;
        argv[0]="/home/nawal/IT215/Lab6/child.out";

        return_val = execvp("/home/nawal/IT215/Lab6/child.out",argv);

        if(return_val==-1){
            printf("Failed to run %s!\n",argv[0]);
        }
    }

    return 0;
}
